---
AIGC:
    ContentProducer: Minimax Agent AI
    ContentPropagator: Minimax Agent AI
    Label: AIGC
    ProduceID: "00000000000000000000000000000000"
    PropagateID: "00000000000000000000000000000000"
    ReservedCode1: 304402202a43b5829a30dc064ebb035246f9443514cca2be73137d63f764ca12b1690e9b022051ce706813ace60ff9a60a58640e2831de8e10859ed7939a3ca69cb8e1c1c6ee
    ReservedCode2: 3045022100a606b34d61375ba0257b120120a628201bfdfa3a8462b51b50d5f58782c783380220577fec3ea1715db27308f7385b4537acc366c73919b3e951e10a338f084f0fae
---

# Ray + MLOps 企业级机器学习全生命周期管理平台

## 技术栈版本

| 组件 | 版本 | 发布日期 | 状态 |
|------|------|----------|------|
| **Ray** | 2.54.1 | 2025-03-25 | ✅ 最新稳定版 |
| **MLflow** | 3.10.1 | 2025-03-05 | ✅ 最新稳定版 |
| **PyTorch** | 2.6.0 | 2025-01-29 | ✅ 最新稳定版 (安全修复) |
| Python | 3.10 | - | ✅ 推荐版本 |

> **注**: MLflow 和 Ray 均无官方 LTS 版本，建议使用最新稳定版以获取安全修复和性能优化。
>
> ⚠️ **重要安全更新**: PyTorch ≤ 2.5.1 存在 CVE-2025-32434 远程命令执行漏洞 (CVSS 9.3)，**必须升级到 2.6.0+**

## 架构概览

```
┌─────────────────────────────────────────────────────────────────┐
│                        Control Plane                             │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────────┐ │
│  │ MLflow   │  │ Ray AIR  │  │Prometheus│  │  Version Control │ │
│  │ Tracking  │  │  Train   │  │Grafana   │  │  (Git, DVC)     │ │
│  └────┬─────┘  └────┬─────┘  └────┬─────┘  └────────┬─────────┘ │
└───────┼─────────────┼─────────────┼────────────────┼───────────┘
        │             │             │                │
        ▼             ▼             ▼                ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Compute Plane (Ray Cluster)                   │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────┐              │
│  │   Head     │◄─►│   Workers   │◄─►│  Object     │              │
│  │   Node     │  │   Nodes     │  │  Store      │              │
│  └─────────────┘  └─────────────┘  └─────────────┘              │
└─────────────────────────────────────────────────────────────────┘
        │
        ▼
┌─────────────────────────────────────────────────────────────────┐
│                     Serving Plane (Ray Serve)                     │
│  ┌─────────────┐  ┌─────────────┐  ┌─────────────────────────┐  │
│  │  Model V1   │  │  Model V2   │  │  Canary/A/B Testing     │  │
│  │  (Active)   │  │ (Staging)  │  │  Traffic Splitting       │  │
│  └──────┬──────┘  └──────┬──────┘  └───────────┬─────────────┘  │
└─────────┼─────────────────┼────────────────────┼────────────────┘
          │                 │                    │
          ▼                 ▼                    ▼
┌─────────────────────────────────────────────────────────────────┐
│                      Observability Layer                          │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐  ┌──────────────────┐ │
│  │ Metrics  │  │  Logs    │  │ Traces   │  │   Alerts        │ │
│  │(Prometheus│  │(Loki)    │  │(Jaeger)  │  │  (PagerDuty)   │ │
│  └──────────┘  └──────────┘  └──────────┘  └──────────────────┘ │
└─────────────────────────────────────────────────────────────────┘
```

## 核心特性

- **可观测性**: 全链路指标、日志、追踪
- **多版本管理**: 模型版本化、配置版本化
- **快速回滚**: 一键回滚到任意稳定版本
- **金丝雀发布**: 渐进式流量切换
- **A/B 测试**: 多版本并行验证

## 可观测性栈 (Observability Stack)

### Prometheus 指标采集

平台暴露以下关键指标供 Prometheus 采集:

```yaml
# 训练指标
ray_training_steps_total          # 训练总步数
ray_training_loss                 # 训练损失分布
ray_training_duration_seconds     # 训练持续时间
ray_gpu_utilization               # GPU 利用率
ray_memory_usage_bytes            # 内存使用量

# 服务指标
ray_serve_requests_total          # 请求总数 (按版本/状态标签)
ray_serve_request_latency_seconds # 请求延迟分布
ray_serve_active_versions         # 当前活跃版本数
ray_serve_rollback_total          # 回滚次数
ray_serve_canary_traffic_percent  # 金丝雀流量百分比
```

### Grafana 仪表板

预配置的 Grafana 仪表板包括:

| 仪表板 | 描述 |
|--------|------|
| Ray Cluster Overview | 集群整体状态、节点分布、资源使用 |
| Training Metrics | 损失曲线、GPU 利用率、训练速度 |
| Serve Performance | QPS、延迟分布、错误率 |
| Model Versioning | 版本分布、回滚历史、活跃模型 |

### MLflow 集成

实验追踪配置:

```python
# src/training/trainer.py
from mlops_ray_enterprise.src.training.trainer import ObservabilityManager

observability = ObservabilityManager(
    mlflow_tracking_uri="http://mlflow.monitoring:5000"
)

# 自动记录: 指标、参数、产物、模型
observability.log_metrics({"accuracy": 0.95}, step=100)
observability.log_params({"learning_rate": 0.001})
```

## 快速开始

### 1. 部署 Kubernetes 资源

```bash
# 创建命名空间
kubectl apply -f k8s/ray-cluster.yaml

# 部署可观测性栈
kubectl apply -f k8s/observability-stack.yaml

# 验证部署
kubectl get pods -n mlops
kubectl get pods -n monitoring
```

### 2. 访问服务

| 服务 | 地址 | 默认凭证 |
|------|------|----------|
| Ray Dashboard | http://<ray-dashboard-ip>:8265 | - |
| Grafana | http://<grafana-ip>:3000 | admin / admin123 |
| MLflow | http://<mlflow-ip>:5000 | - |
| Prometheus | http://<prometheus-ip>:9090 | - |
| Ray Serve API | http://<serve-ip>:8000 | - |

### 3. 训练模型

```python
from mlops_ray_enterprise.src.training.trainer import (
    RayEnterpriseTrainer,
    ObservabilityManager,
    VersionManager
)

# 初始化组件
observability = ObservabilityManager(
    mlflow_tracking_uri="http://mlflow.monitoring:5000"
)
version_manager = VersionManager("./model_registry")

# 创建训练器
trainer = RayEnterpriseTrainer(
    config={"model_type": "simple_cnn", "learning_rate": 0.001},
    observability=observability,
    version_manager=version_manager
)

# 训练并注册
version = trainer.train({
    "num_workers": 4,
    "epochs": 20,
    "use_gpu": True
})

# 提升到生产
version_manager.promote_to_production(version.version_id)
```

### 4. 部署服务

```python
from mlops_ray_enterprise.src.serving.serve_manager import (
    ServeEnterpriseManager,
    CanaryConfig
)

manager = ServeEnterpriseManager()

# 初始化
await manager.initialize()

# 部署生产版本
await manager.deploy_production(version="v1.0.0", num_replicas=3)

# 金丝雀测试
await manager.deploy_with_canary(
    canary_version="v2.0.0",
    production_version="v1.0.0",
    canary_percentage=10.0,
    auto_rollback=True
)
```

## 金丝雀部署工作流

```
┌─────────────────────────────────────────────────────────────┐
│                    金丝雀部署工作流                           │
│                                                              │
│  1. 部署 v2.0.0 (金丝雀) → 10% 流量                         │
│                    ↓                                        │
│  2. 监控 5 分钟，分析指标:                                    │
│     - 错误率 < 5%                                           │
│     - 延迟 < 500ms                                         │
│     - 成功率 > 95%                                          │
│                    ↓                                        │
│  3a. 指标合格 → 自动/手动提升 → 100% v2.0.0                 │
│                    OR                                       │
│  3b. 指标异常 → 自动回滚 → 100% v1.0.0                      │
└─────────────────────────────────────────────────────────────┘
```

## 配置参考

### project.toml

```toml
[project]
ray_version = "2.54.1"
mlflow_version = "3.10.1"
python_version = "3.10"

[mlflow]
tracking_uri = "http://mlflow:5000"
registry_uri = "http://mlflow:5000"
artifact_root = "s3://mlflow-artifacts"

[observability]
mlflow = { enable = true, version = "3.10.1" }
prometheus = { enable = true, port = 9090 }
grafana = { enable = true, port = 3000 }

[rollback]
max_versions = 10
auto_rollback_threshold = 0.95
health_check_interval = 30
```

### Python 依赖 (requirements.txt)

```txt
# 核心组件
ray==2.54.1
mlflow==3.10.1

# Ray AIR 组件
ray[train]==2.54.1
ray[serve]==2.54.1
ray[tune]==2.54.1
ray[data]==2.54.1

# 深度学习框架 (⚠️ 必须 >= 2.6.0 修复安全漏洞)
torch>=2.6.0
torchvision>=0.21.0
torchaudio>=2.6.0

# 其他 ML 库
tensorflow>=2.18.0
xgboost>=2.0.0
scikit-learn>=1.5.0

# 数据版本控制
dvc>=3.66.1

# 可观测性
prometheus-client>=0.19.0
grafana-api>=1.0.0

# 数据库
pymysql>=1.1.0
aiomysql>=0.2.0
beanie>=1.25.0
motor>=3.6.0
```

## 文件结构

```
mlops_ray_enterprise/
├── README.md                    # 本文档
├── project.toml                 # 项目配置
├── src/
│   ├── training/
│   │   └── trainer.py           # 分布式训练 + 可观测性
│   ├── serving/
│   │   └── serve_manager.py     # 金丝雀部署 + 回滚
│   └── data/
│       └── doris_client.py     # Doris 客户端 (同步+异步)
└── k8s/
    ├── ray-cluster.yaml         # Ray 集群配置
    └── observability-stack.yaml # 监控栈配置
```

## 数据层 - Apache Doris 集成

### 推荐 Python 库

由于 **Doris 完全兼容 MySQL 协议**，推荐使用以下库组合：

| 库 | 类型 | 用途 |
|------|------|------|
| **PyMySQL** | 同步 | 企业级同步操作 |
| **aiomysql** | 异步 | 高性能异步操作 |

### 安装

```bash
pip install pymysql aiomysql cryptography
```

### 快速使用

```python
from mlops_ray_enterprise.src.data.doris_client import DorisSyncClient, DorisAsyncClient, DorisConfig

# 同步客户端
config = DorisConfig(
    host="doris-fe.example.com",
    port=9030,
    user="doris_user",
    password="password123",
    database="analytics"
)

with DorisSyncClient(config) as client:
    # 查询
    results = client.query_all("SELECT * FROM page_views WHERE dt = %s", ("2025-01-01",))

    # 批量插入
    data_list = [{"user_id": 1, "page": "/home", "dt": "2025-01-01"}]
    inserted = client.insert_batch("page_views", data_list)

# 异步客户端
async def async_query():
    async with DorisAsyncClient(config) as client:
        results = await client.query_all("SELECT COUNT(*) FROM users")
        return results
```
