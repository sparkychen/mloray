"""
Enterprise-grade Apache Doris Python Client
支持同步和异步操作

Doris 完全兼容 MySQL 协议，使用 PyMySQL (同步) 和 aiomysql (异步)
"""

import asyncio
from typing import Any, Dict, List, Optional, Union
from contextlib import contextmanager
from dataclasses import dataclass
from datetime import datetime
import json

import pymysql
from pymysql.cursors import DictCursor, SSCursor
import aiomysql
from aiomysql import Pool


@dataclass
class DorisConfig:
    """Doris 连接配置"""
    host: str = "localhost"
    port: int = 9030
    user: str = "root"
    password: str = ""
    database: str = ""
    charset: str = "utf8mb4"
    max_pool_size: int = 10
    min_pool_size: int = 1
    pool_recycle: int = 3600
    connect_timeout: int = 30
    read_timeout: int = 60
    write_timeout: int = 60


class DorisSyncClient:
    """
    Doris 同步客户端

    使用 PyMySQL 实现，支持：
    - SQL 查询
    - 批量插入
    - 事务管理
    - 连接池
    """

    def __init__(self, config: DorisConfig):
        self.config = config
        self._pool: Optional[pymysql.connections.Connection] = None
        self._connect()

    def _connect(self):
        """建立连接"""
        self._pool = pymysql.connect(
            host=self.config.host,
            port=self.config.port,
            user=self.config.user,
            password=self.config.password,
            database=self.config.database,
            charset=self.config.charset,
            connect_timeout=self.config.connect_timeout,
            read_timeout=self.config.read_timeout,
            write_timeout=getattr(self.config, 'write_timeout', 60),
            cursorclass=DictCursor,
            autocommit=False
        )

    def execute(self, sql: str, params: Optional[tuple] = None) -> pymysql.cursors.Cursor:
        """执行 SQL"""
        with self._pool.cursor() as cursor:
            cursor.execute(sql, params)
            return cursor

    def query_one(self, sql: str, params: Optional[tuple] = None) -> Optional[Dict]:
        """查询单条"""
        cursor = self.execute(sql, params)
        result = cursor.fetchone()
        cursor.close()
        return result

    def query_all(self, sql: str, params: Optional[tuple] = None) -> List[Dict]:
        """查询全部"""
        cursor = self.execute(sql, params)
        result = cursor.fetchall()
        cursor.close()
        return list(result)

    def query_stream(self, sql: str, params: Optional[tuple] = None):
        """流式查询 - 适合大数据量"""
        cursor = self._pool.cursor(SSCursor)
        cursor.execute(sql, params)
        try:
            while True:
                row = cursor.fetchone()
                if row is None:
                    break
                yield row
        finally:
            cursor.close()

    def insert(self, table: str, data: Dict[str, Any]) -> int:
        """插入单条"""
        columns = ", ".join(f"`{k}`" for k in data.keys())
        placeholders = ", ".join(["%s"] * len(data))
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"
        cursor = self.execute(sql, tuple(data.values()))
        self._pool.commit()
        cursor.close()
        return cursor.lastrowid

    def insert_batch(self, table: str, data_list: List[Dict[str, Any]], batch_size: int = 1000) -> int:
        """批量插入 - 自动分批"""
        if not data_list:
            return 0

        columns = ", ".join(f"`{k}`" for k in data_list[0].keys())
        placeholders = ", ".join(["%s"] * len(data_list[0]))
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"

        total_inserted = 0
        for i in range(0, len(data_list), batch_size):
            batch = data_list[i:i + batch_size]
            values = [tuple(row.values()) for row in batch]

            cursor = self._pool.cursor()
            cursor.executemany(sql, values)
            total_inserted += cursor.rowcount
            cursor.close()

        self._pool.commit()
        return total_inserted

    def insert_ignore(self, table: str, data: Dict[str, Any]) -> int:
        """插入或忽略重复"""
        columns = ", ".join(f"`{k}`" for k in data.keys())
        placeholders = ", ".join(["%s"] * len(data))
        sql = f"INSERT IGNORE INTO {table} ({columns}) VALUES ({placeholders})"
        cursor = self.execute(sql, tuple(data.values()))
        self._pool.commit()
        cursor.close()
        return cursor.rowcount

    def replace(self, table: str, data: Dict[str, Any]) -> int:
        """替换插入 (先删后插)"""
        columns = ", ".join(f"`{k}`" for k in data.keys())
        placeholders = ", ".join(["%s"] * len(data))
        sql = f"REPLACE INTO {table} ({columns}) VALUES ({placeholders})"
        cursor = self.execute(sql, tuple(data.values()))
        self._pool.commit()
        cursor.close()
        return cursor.rowcount

    def update(self, table: str, data: Dict[str, Any], where: str, where_params: Optional[tuple] = None) -> int:
        """更新数据"""
        set_clause = ", ".join(f"`{k}` = %s" for k in data.keys())
        sql = f"UPDATE {table} SET {set_clause} WHERE {where}"
        params = tuple(data.values()) + (where_params or ())
        cursor = self.execute(sql, params)
        self._pool.commit()
        cursor.close()
        return cursor.rowcount

    def delete(self, table: str, where: str, where_params: Optional[tuple] = None) -> int:
        """删除数据"""
        sql = f"DELETE FROM {table} WHERE {where}"
        cursor = self.execute(sql, where_params)
        self._pool.commit()
        cursor.close()
        return cursor.rowcount

    def begin(self):
        """开启事务"""
        self._pool.begin()

    def commit(self):
        """提交事务"""
        self._pool.commit()

    def rollback(self):
        """回滚事务"""
        self._pool.rollback()

    def close(self):
        """关闭连接"""
        if self._pool:
            self._pool.close()

    def __enter__(self):
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        self.close()


class DorisAsyncClient:
    """
    Doris 异步客户端

    使用 aiomysql 实现，支持：
    - 异步 SQL 查询
    - 异步批量插入
    - 连接池管理
    - 异步上下文管理器
    """

    def __init__(self, config: DorisConfig):
        self.config = config
        self._pool: Optional[Pool] = None

    async def connect(self):
        """建立连接池"""
        self._pool = await aiomysql.create_pool(
            host=self.config.host,
            port=self.config.port,
            user=self.config.user,
            password=self.config.password,
            db=self.config.database,
            charset=self.config.charset,
            minsize=self.config.min_pool_size,
            maxsize=self.config.max_pool_size,
            pool_recycle=self.config.pool_recycle,
            connect_timeout=self.config.connect_timeout,
            read_timeout=self.config.read_timeout,
            autocommit=False
        )

    async def close(self):
        """关闭连接池"""
        if self._pool:
            self._pool.close()
            await self._pool.wait_closed()

    async def execute(self, sql: str, params: Optional[tuple] = None):
        """执行 SQL"""
        async with self._pool.acquire() as conn:
            async with conn.cursor(aiomysql.DictCursor) as cursor:
                await cursor.execute(sql, params)
                return cursor

    async def query_one(self, sql: str, params: Optional[tuple] = None) -> Optional[Dict]:
        """查询单条"""
        cursor = await self.execute(sql, params)
        result = await cursor.fetchone()
        cursor.close()
        return result

    async def query_all(self, sql: str, params: Optional[tuple] = None) -> List[Dict]:
        """查询全部"""
        cursor = await self.execute(sql, params)
        result = await cursor.fetchall()
        cursor.close()
        return list(result)

    async def insert(self, table: str, data: Dict[str, Any]) -> int:
        """插入单条"""
        columns = ", ".join(f"`{k}`" for k in data.keys())
        placeholders = ", ".join(["%s"] * len(data))
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"

        async with self._pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute(sql, tuple(data.values()))
                await conn.commit()
                return cursor.lastrowid

    async def insert_batch(self, table: str, data_list: List[Dict[str, Any]], batch_size: int = 1000) -> int:
        """批量插入"""
        if not data_list:
            return 0

        columns = ", ".join(f"`{k}`" for k in data_list[0].keys())
        placeholders = ", ".join(["%s"] * len(data_list[0]))
        sql = f"INSERT INTO {table} ({columns}) VALUES ({placeholders})"

        total_inserted = 0
        async with self._pool.acquire() as conn:
            for i in range(0, len(data_list), batch_size):
                batch = data_list[i:i + batch_size]
                values = [tuple(row.values()) for row in batch]

                async with conn.cursor() as cursor:
                    await cursor.executemany(sql, values)
                    total_inserted += cursor.rowcount

            await conn.commit()

        return total_inserted

    async def insert_ignore(self, table: str, data: Dict[str, Any]) -> int:
        """插入或忽略"""
        columns = ", ".join(f"`{k}`" for k in data.keys())
        placeholders = ", ".join(["%s"] * len(data))
        sql = f"INSERT IGNORE INTO {table} ({columns}) VALUES ({placeholders})"

        async with self._pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute(sql, tuple(data.values()))
                await conn.commit()
                return cursor.rowcount

    async def replace(self, table: str, data: Dict[str, Any]) -> int:
        """替换插入"""
        columns = ", ".join(f"`{k}`" for k in data.keys())
        placeholders = ", ".join(["%s"] * len(data))
        sql = f"REPLACE INTO {table} ({columns}) VALUES ({placeholders})"

        async with self._pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute(sql, tuple(data.values()))
                await conn.commit()
                return cursor.rowcount

    async def update(self, table: str, data: Dict[str, Any], where: str, where_params: Optional[tuple] = None) -> int:
        """更新数据"""
        set_clause = ", ".join(f"`{k}` = %s" for k in data.keys())
        sql = f"UPDATE {table} SET {set_clause} WHERE {where}"
        params = tuple(data.values()) + (where_params or ())

        async with self._pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute(sql, params)
                await conn.commit()
                return cursor.rowcount

    async def delete(self, table: str, where: str, where_params: Optional[tuple] = None) -> int:
        """删除数据"""
        sql = f"DELETE FROM {table} WHERE {where}"

        async with self._pool.acquire() as conn:
            async with conn.cursor() as cursor:
                await cursor.execute(sql, where_params)
                await conn.commit()
                return cursor.rowcount

    async def begin(self):
        """开启事务"""
        async with self._pool.acquire() as conn:
            await conn.begin()

    async def commit(self):
        """提交事务"""
        async with self._pool.acquire() as conn:
            await conn.commit()

    async def rollback(self):
        """回滚事务"""
        async with self._pool.acquire() as conn:
            await conn.rollback()

    async def __aenter__(self):
        await self.connect()
        return self

    async def __aexit__(self, exc_type, exc_val, exc_tb):
        await self.close()


class DorisClient:
    """
    统一客户端接口

    同时支持同步和异步操作
    """

    def __init__(self, config: DorisConfig):
        self.config = config
        self.sync = DorisSyncClient(config)

    async def async_client(self) -> DorisAsyncClient:
        """获取异步客户端"""
        client = DorisAsyncClient(self.config)
        await client.connect()
        return client

    def close(self):
        """关闭同步客户端"""
        self.sync.close()


# ==================== 使用示例 ====================

def sync_example():
    """同步使用示例"""
    config = DorisConfig(
        host="doris-fe.example.com",
        port=9030,
        user="doris_user",
        password="password123",
        database="analytics"
    )

    with DorisSyncClient(config) as client:
        # 查询
        results = client.query_all("SELECT * FROM page_views WHERE dt = %s", ("2025-01-01",))
        print(f"查询到 {len(results)} 条记录")

        # 批量插入
        data_list = [
            {"user_id": 1, "page": "/home", "dt": "2025-01-01"},
            {"user_id": 2, "page": "/about", "dt": "2025-01-01"},
        ]
        inserted = client.insert_batch("page_views", data_list)
        print(f"插入了 {inserted} 条记录")


async def async_example():
    """异步使用示例"""
    config = DorisConfig(
        host="doris-fe.example.com",
        port=9030,
        user="doris_user",
        password="password123",
        database="analytics"
    )

    async with DorisAsyncClient(config) as client:
        # 并发查询
        results = await asyncio.gather(
            client.query_all("SELECT COUNT(*) as cnt FROM page_views"),
            client.query_all("SELECT * FROM users LIMIT 100")
        )
        print(f"查询完成: {results}")


if __name__ == "__main__":
    import sys

    if len(sys.argv) > 1 and sys.argv[1] == "async":
        asyncio.run(async_example())
    else:
        sync_example()
