"""
Ray + MLflow 企业级分布式训练模块
支持可观测性、多版本追踪、自动回滚
"""

import ray
import mlflow
import torch
import torch.nn as nn
from typing import Dict, Any, Optional, List
from dataclasses import dataclass, field
from datetime import datetime
import json
import hashlib
import logging
from pathlib import Path

# Ray AIR imports
from ray import train, tune
from ray.train import Checkpoint, CheckpointConfig, RunConfig, ScalingConfig
from ray.train.torch import TorchTrainer, TorchCheckpoint
from ray.train.torch.torch_trainer import TrainingIterator

# Observability
from prometheus_client import Counter, Histogram, Gauge, start_http_server
import psutil

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Prometheus Metrics
METRICS = {
    "training_steps": Counter("ray_training_steps_total", "Total training steps"),
    "training_loss": Histogram("ray_training_loss", "Training loss", buckets=[0.01, 0.1, 0.5, 1.0, 5.0]),
    "model_version": Gauge("ray_model_version", "Current model version"),
    "training_duration": Histogram("ray_training_duration_seconds", "Training duration"),
    "gpu_utilization": Gauge("ray_gpu_utilization", "GPU utilization"),
    "memory_usage": Gauge("ray_memory_usage_bytes", "Memory usage in bytes"),
}


@dataclass
class ModelVersion:
    """模型版本信息"""
    version_id: str
    model_path: str
    metrics: Dict[str, float]
    config: Dict[str, Any]
    created_at: str
    commit_hash: str
    status: str = "staging"  # staging, production, archived
    rollback_available: bool = True

    def to_dict(self) -> Dict:
        return {
            "version_id": self.version_id,
            "model_path": self.model_path,
            "metrics": self.metrics,
            "config": self.config,
            "created_at": self.created_at,
            "commit_hash": self.commit_hash,
            "status": self.status,
            "rollback_available": self.rollback_available
        }

    @classmethod
    def from_dict(cls, data: Dict) -> "ModelVersion":
        return cls(**data)


class VersionManager:
    """模型版本管理器"""

    def __init__(self, storage_path: str = "./model_registry"):
        self.storage_path = Path(storage_path)
        self.storage_path.mkdir(parents=True, exist_ok=True)
        self.versions: List[ModelVersion] = []
        self._load_versions()

    def _load_versions(self):
        """从磁盘加载已保存的版本"""
        version_file = self.storage_path / "versions.json"
        if version_file.exists():
            with open(version_file) as f:
                data = json.load(f)
                self.versions = [ModelVersion.from_dict(v) for v in data]

    def _save_versions(self):
        """保存版本信息到磁盘"""
        version_file = self.storage_path / "versions.json"
        with open(version_file, "w") as f:
            json.dump([v.to_dict() for v in self.versions], f, indent=2)

    def register_version(
        self,
        model_path: str,
        metrics: Dict[str, float],
        config: Dict[str, Any],
        commit_hash: str
    ) -> ModelVersion:
        """注册新版本"""
        version_id = hashlib.md5(
            f"{model_path}{datetime.now().isoformat()}".encode()
        ).hexdigest()[:8]

        version = ModelVersion(
            version_id=version_id,
            model_path=model_path,
            metrics=metrics,
            config=config,
            created_at=datetime.now().isoformat(),
            commit_hash=commit_hash
        )

        self.versions.append(version)
        self._save_versions()

        # 限制版本数量
        if len(self.versions) > 10:
            self.versions = self.versions[-10:]

        METRICS["model_version"].set(float(version_id, 16) % 1000)

        logger.info(f"Registered new model version: {version_id}")
        return version

    def promote_to_production(self, version_id: str) -> bool:
        """将版本提升为生产版本"""
        for v in self.versions:
            if v.version_id == version_id:
                # 将之前的生产版本设为 archived
                for prev in self.versions:
                    if prev.status == "production":
                        prev.status = "archived"
                v.status = "production"
                self._save_versions()
                logger.info(f"Promoted version {version_id} to production")
                return True
        return False

    def rollback_to_version(self, version_id: str) -> Optional[ModelVersion]:
        """回滚到指定版本"""
        for v in self.versions:
            if v.version_id == version_id and v.rollback_available:
                # 将当前生产版本设为 staging
                for prod in self.versions:
                    if prod.status == "production":
                        prod.status = "staging"
                v.status = "production"
                self._save_versions()
                logger.info(f"Rolled back to version {version_id}")
                return v
        return None

    def get_production_version(self) -> Optional[ModelVersion]:
        """获取当前生产版本"""
        for v in self.versions:
            if v.status == "production":
                return v
        return None

    def list_versions(self, status: Optional[str] = None) -> List[ModelVersion]:
        """列出所有版本"""
        if status:
            return [v for v in self.versions if v.status == status]
        return self.versions


class ObservabilityManager:
    """可观测性管理器"""

    def __init__(self, mlflow_tracking_uri: str):
        self.mlflow_tracking_uri = mlflow_tracking_uri
        self.experiment_name = "ray_enterprise_training"
        self._setup_mlflow()
        self._start_prometheus_server()

    def _setup_mlflow(self):
        """配置 MLflow"""
        mlflow.set_tracking_uri(self.mlflow_tracking_uri)
        mlflow.set_experiment(self.experiment_name)
        logger.info(f"MLflow configured: {self.mlflow_tracking_uri}")

    def _start_prometheus_server(self, port: int = 9091):
        """启动 Prometheus metrics HTTP 服务器"""
        try:
            start_http_server(port)
            logger.info(f"Prometheus metrics server started on port {port}")
        except Exception as e:
            logger.warning(f"Failed to start Prometheus server: {e}")

    def log_metrics(self, metrics: Dict[str, float], step: int):
        """记录指标到 MLflow"""
        with mlflow.start_run() as run:
            for key, value in metrics.items():
                mlflow.log_metric(key, value, step=step)

    def log_artifact(self, local_path: str, artifact_name: str):
        """记录产物到 MLflow"""
        with mlflow.start_run() as run:
            mlflow.log_artifact(local_path, artifact_name)

    def log_params(self, params: Dict[str, Any]):
        """记录参数到 MLflow"""
        with mlflow.start_run() as run:
            mlflow.log_params(params)


class RayEnterpriseTrainer:
    """Ray 企业级分布式训练器"""

    def __init__(
        self,
        config: Dict[str, Any],
        observability: Optional[ObservabilityManager] = None,
        version_manager: Optional[VersionManager] = None
    ):
        self.config = config
        self.observability = observability
        self.version_manager = version_manager
        self.current_run_id = None

    def train(self, train_config: Dict[str, Any]) -> ModelVersion:
        """执行分布式训练"""
        logger.info("Starting Ray distributed training")

        # 初始化 Ray
        if not ray.is_initialized():
            ray.init(
                runtime_env={
                    "working_dir": ".",
                    "env_vars": {
                        "MLFLOW_TRACKING_URI": self.observability.mlflow_tracking_uri if self.observability else ""
                    }
                }
            )

        # 创建训练器
        scaling_config = ScalingConfig(
            num_workers=train_config.get("num_workers", 2),
            use_gpu=train_config.get("use_gpu", False),
            resources_per_worker={
                "CPU": train_config.get("cpus_per_worker", 2),
                "GPU": train_config.get("gpus_per_worker", 0)
            }
        )

        # 配置 Checkpoint
        run_config = RunConfig(
            checkpoint_config=CheckpointConfig(
                num_to_keep=train_config.get("num_checkpoints", 3),
                checkpoint_frequency=train_config.get("checkpoint_freq", 10)
            ),
            storage_path=train_config.get("storage_path", "/tmp/ray_results")
        )

        # 记录配置到 MLflow
        if self.observability:
            self.observability.log_params(self.config)

        # 创建 Checkpoint 目录
        checkpoint_dir = Path(train_config.get("storage_path", "/tmp")) / "checkpoints"
        checkpoint_dir.mkdir(parents=True, exist_ok=True)

        # 开始训练
        start_time = datetime.now()

        trainer = TorchTrainer(
            train_loop_per_worker=self._training_loop,
            train_loop_config={
                "config": self.config,
                "train_config": train_config,
                "checkpoint_dir": str(checkpoint_dir)
            },
            scaling_config=scaling_config,
            run_config=run_config
        )

        result = trainer.fit()

        duration = (datetime.now() - start_time).total_seconds()
        METRICS["training_duration"].observe(duration)

        # 注册模型版本
        model_path = str(checkpoint_dir / f"model_{result.checkpoint.id}")
        version = self.version_manager.register_version(
            model_path=model_path,
            metrics=result.metrics,
            config=self.config,
            commit_hash=train_config.get("commit_hash", "unknown")
        )

        return version

    def _training_loop(self, config):
        """每个 worker 上的训练循环"""
        from torch import nn, optim
        from ray.train import get_context

        world_size = get_context().get_world_size()
        rank = get_context().get_world_rank()

        # 创建模型
        model = self._build_model()
        model = model.to(torch.device("cuda" if torch.cuda.is_available() else "cpu"))
        model = train.torch.prepare_model(model)

        criterion = nn.CrossEntropyLoss()
        optimizer = optim.Adam(model.parameters(), lr=config["config"]["learning_rate"])

        # 模拟训练循环
        for epoch in range(config["train_config"].get("epochs", 10)):
            model.train()
            running_loss = 0.0

            for batch_idx in range(100):
                METRICS["training_steps"].inc()

                # 前向传播
                inputs = torch.randn(32, 784).to(model.device)
                targets = torch.randint(0, 10, (32,)).to(model.device)

                optimizer.zero_grad()
                outputs = model(inputs)
                loss = criterion(outputs, targets)

                # 反向传播
                loss.backward()
                optimizer.step()

                running_loss += loss.item()

                if batch_idx % 10 == 0:
                    METRICS["training_loss"].observe(loss.item())
                    if self.observability and rank == 0:
                        self.observability.log_metrics(
                            {"loss": loss.item(), "epoch": epoch, "batch": batch_idx},
                            step=epoch * 100 + batch_idx
                        )

            if rank == 0:
                avg_loss = running_loss / 100
                train.report({"loss": avg_loss, "epoch": epoch})
                logger.info(f"Epoch {epoch}: Loss = {avg_loss:.4f}")

        # 保存 checkpoint
        checkpoint = TorchCheckpoint.from_model(model)
        train.report({}, checkpoint=checkpoint)

    def _build_model(self) -> nn.Module:
        """构建模型"""
        model_type = self.config.get("model_type", "simple_cnn")

        if model_type == "simple_cnn":
            return nn.Sequential(
                nn.Conv2d(1, 32, 3),
                nn.ReLU(),
                nn.MaxPool2d(2),
                nn.Conv2d(32, 64, 3),
                nn.ReLU(),
                nn.MaxPool2d(2),
                nn.Flatten(),
                nn.Linear(64 * 5 * 5, 128),
                nn.ReLU(),
                nn.Linear(128, 10)
            )
        else:
            raise ValueError(f"Unknown model type: {model_type}")


def main():
    """主函数示例"""
    # 初始化组件
    observability = ObservabilityManager(
        mlflow_tracking_uri="http://mlflow:5000"
    )

    version_manager = VersionManager(
        storage_path="./model_registry"
    )

    # 训练配置
    config = {
        "model_type": "simple_cnn",
        "learning_rate": 0.001,
        "batch_size": 32,
        "optimizer": "adam"
    }

    train_config = {
        "num_workers": 4,
        "use_gpu": True,
        "epochs": 20,
        "checkpoint_freq": 5,
        "storage_path": "/tmp/ray_training"
    }

    # 创建训练器
    trainer = RayEnterpriseTrainer(
        config=config,
        observability=observability,
        version_manager=version_manager
    )

    # 执行训练
    version = trainer.train(train_config)

    # 提升到生产环境
    version_manager.promote_to_production(version.version_id)

    print(f"Training completed. Model version: {version.version_id}")


if __name__ == "__main__":
    main()
